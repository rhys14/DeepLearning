import matplotlib.pyplot as plt
import matplotlib.patches as patches

# ==========================================
# 1. CANVAS SETUP (DARK THEME)
# ==========================================
plt.style.use("dark_background")
fig, ax = plt.subplots(figsize=(11, 6.4), facecolor="#0B1120")
ax.set_facecolor("#0B1120")

# Helper function to draw rounded cards with guaranteed text clearance
def draw_card(ax, x, y, w, h, fill="#1E293B", border="#38BDF8"):
    rect = patches.FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.015,rounding_size=0.035",
        facecolor=fill,
        edgecolor=border,
        linewidth=1.8,
        zorder=2
    )
    ax.add_patch(rect)

# Helper function to draw arrows
def draw_arrow(ax, start, end):
    ax.annotate(
        "", xy=end, xytext=start,
        arrowprops=dict(arrowstyle="->", color="#94A3B8", lw=2, shrinkA=4, shrinkB=4),
        zorder=1
    )

# ==========================================
# 2. TOP CARD: GALAXY10 DECALS DATASET
# ==========================================
draw_card(ax, 0.22, 0.81, 0.56, 0.14, border="#818CF8")
ax.text(0.50, 0.915, "Galaxy10 DECALS Dataset", ha="center", va="top",
        fontsize=13, fontweight="bold", color="#A5B4FC", zorder=3)
ax.text(0.50, 0.865, "17,736 Total Images   •   10 Morphological Classes\nStandardized Astronomical Multi-Class Catalog",
        ha="center", va="top", fontsize=9.5, color="#E2E8F0", linespacing=1.35, zorder=3)

# Arrow from Dataset to Split Badge
draw_arrow(ax, (0.50, 0.81), (0.50, 0.73))

# ==========================================
# 3. INTERMEDIATE BADGE: 80 / 20 SPLIT
# ==========================================
ax.text(0.50, 0.705, "Deterministic 80 / 20 Split (Seed = 42)", ha="center", va="center",
        fontsize=10, fontweight="bold", color="#FBBF24", zorder=3,
        bbox=dict(boxstyle="round,pad=0.35", facecolor="#1E293B", edgecolor="#FBBF24", lw=1.4))

# Branching arrows from badge to the two split cards
draw_arrow(ax, (0.39, 0.68), (0.265, 0.61))
draw_arrow(ax, (0.61, 0.68), (0.735, 0.61))

# ==========================================
# 4. TWO MAIN SPLIT CARDS (80% TRAIN / 20% TEST)
# ==========================================
card_y = 0.31
card_h = 0.30
card_w = 0.41

# --- LEFT: Training Set (80%) ---
train_x = 0.06
draw_card(ax, train_x, card_y, card_w, card_h, border="#38BDF8")
ax.text(train_x + card_w / 2, card_y + card_h - 0.025, "Training Set (80%)",
        ha="center", va="top", fontsize=12, fontweight="bold", color="#38BDF8", zorder=3)

train_bullets = (
    "• 14,189 Images\n\n"
    "• Dynamic On-The-Fly Augmentations:\n"
    "   - Continuous 0°–360° Random Rotations\n"
    "   - Random Horizontal & Vertical Flips\n\n"
    "• Exploits Celestial Rotational Symmetry"
)
ax.text(train_x + 0.035, card_y + card_h - 0.075, train_bullets,
        ha="left", va="top", fontsize=9.5, color="#F1F5F9", linespacing=1.3, zorder=3)

# --- RIGHT: Test Set (20%) ---
test_x = 0.53
draw_card(ax, test_x, card_y, card_w, card_h, border="#34D399")
ax.text(test_x + card_w / 2, card_y + card_h - 0.025, "Test / Evaluation Set (20%)",
        ha="center", va="top", fontsize=12, fontweight="bold", color="#34D399", zorder=3)

test_bullets = (
    "• 3,547 Images\n\n"
    "• Deterministic Evaluation Pipeline:\n"
    "   - Standardized 256px Resize\n"
    "   - Zero Random Augmentations Applied\n\n"
    "• Pure Unseen Benchmark (Zero Data Leakage)"
)
ax.text(test_x + 0.035, card_y + card_h - 0.075, test_bullets,
        ha="left", va="top", fontsize=9.5, color="#F1F5F9", linespacing=1.3, zorder=3)

# Arrows from split cards down to benchmarking box
draw_arrow(ax, (train_x + card_w / 2, card_y), (0.33, 0.20))
draw_arrow(ax, (test_x + card_w / 2, card_y), (0.67, 0.20))

# ==========================================
# 5. BOTTOM CARD: TEAM MODEL BENCHMARKS
# ==========================================
bench_y = 0.05
bench_h = 0.15
draw_card(ax, 0.06, bench_y, 0.88, bench_h, border="#64748B")
ax.text(0.50, bench_y + bench_h - 0.025, "Team Model Benchmarks (Evaluated on Same Partition)",
        ha="center", va="top", fontsize=11.5, fontweight="bold", color="#F1F5F9", zorder=3)

ax.text(0.50, bench_y + bench_h - 0.070,
        "VGG-16 (64.1%)   •   ResNet-18 (76.0%)   •   MobileNetV4 DETR (83.6%)   •   DINOv2 ViT (85.15%)\n"
        "Strict split guarantees all 4 architectures are scored against identical, uncorrupted test galaxies",
        ha="center", va="top", fontsize=9.5, color="#CBD5E1", linespacing=1.35, zorder=3)

# Formatting axes
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")

plt.tight_layout()
output_filename = "experimental_setup_pipeline.png"
plt.savefig(output_filename, dpi=300, bbox_inches="tight", facecolor=fig.get_facecolor())
print(f"[SUCCESS] Clean 80/20 diagram saved as '{output_filename}'!")