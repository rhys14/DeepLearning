import os
import sys
import torch
import torchvision
from PIL import Image

# ==========================================
# 1. SETTINGS & LABELS
# ==========================================
CLASSES = [
    "disturbed", "merging", "round_smooth", "in_between_round_smooth", "cigar_smooth",
    "barred_spiral", "unbarred_tight_spiral", "unbarred_loose_spiral",
    "edge_on_no_bulge", "edge_on_with_bulge"
]
NUM_CLASSES = len(CLASSES)

# Use your backup 76% model if it exists, otherwise use the finetuned checkpoint
if os.path.exists("resnet18_galaxy10_76pct.pth"):
    MODEL_PATH = "resnet18_galaxy10_76pct.pth"
elif os.path.exists("resnet18_galaxy_finetuned.pth"):
    MODEL_PATH = "resnet18_galaxy_finetuned.pth"
else:
    raise FileNotFoundError("Could not find any saved .pth model checkpoint in this folder!")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ==========================================
# 2. IMAGE PREPROCESSING
# ==========================================
preprocess = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),
    torchvision.transforms.CenterCrop(224),
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
])

# ==========================================
# 3. LOAD MODEL ARCHITECTURE & WEIGHTS
# ==========================================
def load_trained_model():
    # Set up ResNet-18 skeleton
    model = torchvision.models.resnet18(weights=None)
    in_features = model.fc.in_features
    model.fc = torch.nn.Linear(in_features, NUM_CLASSES)
    
    # Load your saved weights
    model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
    model = model.to(device)
    model.eval()
    return model

# ==========================================
# 4. PREDICTION FUNCTION
# ==========================================
def predict_image(image_path, model):
    if not os.path.exists(image_path):
        print(f"\n[ERROR] File not found: '{image_path}'")
        print("Make sure the image is in the galaxy_project folder or provide the full path.")
        return

    # Load and preprocess image
    raw_img = Image.open(image_path).convert("RGB")
    tensor_img = preprocess(raw_img).unsqueeze(0).to(device)  # Add batch dimension

    # Forward pass
    with torch.no_grad():
        logits = model(tensor_img)
        probabilities = torch.softmax(logits, dim=1).cpu().numpy()[0]

    # Pair classes with probabilities and sort from highest to lowest
    class_probs = list(zip(CLASSES, probabilities))
    class_probs.sort(key=lambda x: x[1], reverse=True)

    # Display results
    top_class, top_prob = class_probs[0]
    print("\n" + "=" * 50)
    print(f" DEMO PREDICTION: {os.path.basename(image_path)}")
    print(f" Loaded Weights : {MODEL_PATH}")
    print(f" Running On     : {device}")
    print("=" * 50)
    print(f"\n--> TOP PREDICTION: {top_class.upper()} ({top_prob * 100:.2f}%)")
    print("\n--- All 10 Class Probabilities (Ranked) ---")
    print(f"{'Class Name':<28} | {'Probability':<12} | {'Percentage'}")
    print("-" * 55)

    for rank, (name, prob) in enumerate(class_probs, start=1):
        bar = "█" * int(prob * 20)  # Visual bar representation
        print(f"{rank:2d}. {name:<24} | {prob:.4f}       | {prob * 100:6.2f}%  {bar}")
    print("=" * 50 + "\n")

# ==========================================
# 5. ENTRY POINT
# ==========================================
if __name__ == "__main__":
    # If a filename is passed via command line, use it; otherwise default to 'my_galaxy.jpg'
    if len(sys.argv) > 1:
        target_image = sys.argv[1]
    else:
        target_image = "my_galaxy.jpg"

    model = load_trained_model()
    predict_image(target_image, model)