import os
import re
import numpy as np
import matplotlib.pyplot as plt

# ==========================================
# 1. CLASS DEFINITIONS & CLEAN LABELS
# ==========================================
CLASSES = [
    "disturbed", "merging", "round_smooth", "in_between_round_smooth", "cigar_smooth",
    "barred_spiral", "unbarred_tight_spiral", "unbarred_loose_spiral",
    "edge_on_no_bulge", "edge_on_with_bulge"
]

DISPLAY_NAMES = {
    "disturbed": "Disturbed",
    "merging": "Merging",
    "round_smooth": "Round Smooth",
    "in_between_round_smooth": "In-Between Smooth",
    "cigar_smooth": "Cigar Smooth",
    "barred_spiral": "Barred Spiral",
    "unbarred_tight_spiral": "Unbarred Tight Spiral",
    "unbarred_loose_spiral": "Unbarred Loose Spiral",
    "edge_on_no_bulge": "Edge-On (No Bulge)",
    "edge_on_with_bulge": "Edge-On (With Bulge)"
}

# Determine which results file to read
LOG_FILE = "results_galaxy10_76pct.txt" if os.path.exists("results_galaxy10_76pct.txt") else "results.txt"

# ==========================================
# 2. PARSE CONFUSION MATRIX FROM RESULTS.TXT
# ==========================================
if not os.path.exists(LOG_FILE):
    raise FileNotFoundError(f"Could not find '{LOG_FILE}'. Make sure you are in 'galaxy_project'.")

with open(LOG_FILE, "r") as f:
    content = f.read()

# Locate the confusion matrix block
matrix_match = re.search(r"Confusion Matrix.*?:(.*?)(?=\Z|\n\n[A-Z])", content, re.DOTALL)
if not matrix_match:
    raise ValueError("Could not find the Confusion Matrix section in results.txt.")

# Extract all integers within the matrix section
numbers = [int(num) for num in re.findall(r"\b\d+\b", matrix_match.group(1))]

if len(numbers) != 100:
    raise ValueError(f"Expected 100 numbers for a 10x10 matrix, but found {len(numbers)}.")

confusion = np.array(numbers).reshape((10, 10))

# ==========================================
# 3. COMPUTE PER-CLASS RECALL
# ==========================================
# Recall = True Positives / Total True Instances in Class
row_sums = confusion.sum(axis=1)
recalls = np.diag(confusion) / np.maximum(row_sums, 1) * 100

data = []
for i, class_key in enumerate(CLASSES):
    data.append({
        "name": DISPLAY_NAMES[class_key],
        "recall": recalls[i],
        "samples": row_sums[i]
    })

# Sort from lowest to highest so top performers sit at the top of the chart
data.sort(key=lambda x: x["recall"])

labels = [item["name"] for item in data]
scores = [item["recall"] for item in data]

# ==========================================
# 4. PLOT HIGH-CONTRAST PRESENTATION CHART
# ==========================================
# Slide theme: dark navy background to match space presentation decks
plt.style.use("dark_background")
fig, ax = plt.subplots(figsize=(10, 5.8), facecolor="#0B1120")
ax.set_facecolor("#0B1120")

# Color ramp: cool cyan for high performers, muted steel/coral for bottlenecks
bar_colors = []
for s in scores:
    if s >= 80:
        bar_colors.append("#38BDF8")  # Vibrant sky blue
    elif s >= 60:
        bar_colors.append("#818CF8")  # Soft indigo
    else:
        bar_colors.append("#F87171")  # Alert coral/red for bottlenecks

bars = ax.barh(labels, scores, color=bar_colors, height=0.62, edgecolor="none", zorder=3)

# Add exact percentage tags at the tip of each bar
for bar, score in zip(bars, scores):
    ax.text(
        score + 1.2,
        bar.get_y() + bar.get_height() / 2,
        f"{score:.1f}%",
        va="center",
        ha="left",
        fontsize=11,
        fontweight="bold",
        color="#F3F4F6"
    )

# Formatting axes and gridlines
ax.set_xlim(0, 105)
ax.set_xlabel("Recall / Accuracy per Morphological Class (%)", fontsize=12, fontweight="bold", color="#E5E7EB", labelpad=10)
ax.set_title("ResNet-18: Morphological Class Performance", fontsize=15, fontweight="bold", color="#FFFFFF", pad=15)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_color("#4B5563")
ax.spines["bottom"].set_color("#4B5563")

ax.tick_params(axis="y", labelsize=11, colors="#F3F4F6", length=0)
ax.tick_params(axis="x", labelsize=10, colors="#9CA3AF")

# Subtle vertical grid lines
ax.xaxis.grid(True, linestyle="--", alpha=0.25, color="#9CA3AF", zorder=0)

# Reference benchmark line at 76% (Overall Test Accuracy)
ax.axvline(76.0, color="#FBBF24", linestyle=":", linewidth=1.8, label="Overall Test Accuracy (76.0%)", zorder=4)
ax.legend(loc="lower right", frameon=True, facecolor="#1E293B", edgecolor="#334155", fontsize=10)

plt.tight_layout()

# Save high-resolution graphic for slide deck
output_path = "galaxy_recall_chart.png"
plt.savefig(output_path, dpi=300, bbox_inches="tight", facecolor=fig.get_facecolor())
print(f"[SUCCESS] Chart generated and saved to '{output_path}'!")