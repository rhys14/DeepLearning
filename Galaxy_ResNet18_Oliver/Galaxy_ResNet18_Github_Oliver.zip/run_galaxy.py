import os
import time
import numpy as np
import torch
import torchvision
from PIL import Image
from datasets import load_dataset
from torch.utils.data import DataLoader, Dataset

# ==========================================
# 1. SETTINGS & HYPERPARAMETERS
# ==========================================
CLASSES = [
    "disturbed", "merging", "round_smooth", "in_between_round_smooth", "cigar_smooth",
    "barred_spiral", "unbarred_tight_spiral", "unbarred_loose_spiral",
    "edge_on_no_bulge", "edge_on_with_bulge"
]
NUM_CLASSES = len(CLASSES)
BATCH_SIZE = 32
NUM_EPOCHS = 25       # Maximum additional epochs to run
PATIENCE = 6          # Stop if no validation improvement for 6 consecutive epochs
NUM_WORKERS = 2       # Set to 0 if server throws multiprocessing/worker warnings
LOG_FILE = "results.txt"

# Distinct checkpoint paths: read from your 76% baseline, write improvements to finetuned
SOURCE_CHECKPOINT = "resnet18_galaxy10_76pct.pth"
TARGET_CHECKPOINT = "resnet18_galaxy_finetuned.pth"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"--> Using compute device: {device}")

# ==========================================
# 2. DATA AUGMENTATION & TRANSFORMS
# ==========================================
train_transform = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),
    torchvision.transforms.RandomCrop(224),
    torchvision.transforms.RandomHorizontalFlip(p=0.5),
    torchvision.transforms.RandomVerticalFlip(p=0.5),
    torchvision.transforms.RandomRotation(degrees=(0, 360)),
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

eval_transform = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),
    torchvision.transforms.CenterCrop(224),
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ==========================================
# 3. DATASET LOADING & SPLITS
# ==========================================
print("--> Loading Galaxy10 DECALS dataset from cache...")
raw_dataset = load_dataset("matthieulel/galaxy10_decals", split="train")

# 70% Train, 15% Validation, 15% Test
split_1 = raw_dataset.train_test_split(test_size=0.30, seed=42)
train_raw = split_1["train"]
split_2 = split_1["test"].train_test_split(test_size=0.50, seed=42)
val_raw = split_2["train"]
test_raw = split_2["test"]

print(f"--> Dataset splits: Train={len(train_raw)}, Validation={len(val_raw)}, Test={len(test_raw)}")

class GalaxyDataset(Dataset):
    def __init__(self, hf_data, transform=None):
        self.data = hf_data
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        img = item["image"].convert("RGB")
        label = item["label"]
        if self.transform:
            img = self.transform(img)
        return img, label

train_dataset = GalaxyDataset(train_raw, transform=train_transform)
val_dataset = GalaxyDataset(val_raw, transform=eval_transform)
test_dataset = GalaxyDataset(test_raw, transform=eval_transform)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=NUM_WORKERS, pin_memory=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)

# ==========================================
# 4. MODEL INITIALIZATION & UNFREEZING
# ==========================================
print("--> Initializing ResNet-18...")
model = torchvision.models.resnet18(weights=torchvision.models.ResNet18_Weights.IMAGENET1K_V1)

# Replace head for 10 galaxy categories
in_features = model.fc.in_features
model.fc = torch.nn.Linear(in_features, NUM_CLASSES)
model = model.to(device)

# Freeze all layers initially
for param in model.parameters():
    param.requires_grad = False

# Unfreeze layer3, layer4, and fc
for param in model.layer3.parameters():
    param.requires_grad = True

for param in model.layer4.parameters():
    param.requires_grad = True

for param in model.fc.parameters():
    param.requires_grad = True

trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"--> Trainable parameters (layer3 + layer4 + fc): {trainable_params:,}")

# Differential learning rates: smaller for earlier convolutional filters
optimizer = torch.optim.AdamW([
    {"params": model.layer3.parameters(), "lr": 2e-5},
    {"params": model.layer4.parameters(), "lr": 1e-4},
    {"params": model.fc.parameters(),     "lr": 5e-4}
], weight_decay=1e-2)

criterion = torch.nn.CrossEntropyLoss()

# ==========================================
# 5. LOAD SOURCE CHECKPOINT (76% MODEL)
# ==========================================
if os.path.exists(SOURCE_CHECKPOINT):
    print(f"--> Loading baseline weights from '{SOURCE_CHECKPOINT}'...")
    model.load_state_dict(torch.load(SOURCE_CHECKPOINT, map_location=device))
    
    # Evaluate baseline validation loss to establish the threshold to beat
    model.eval()
    val_loss_total = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images.to(device))
            val_loss_total += criterion(outputs, labels.to(device)).item() * len(labels)
    best_val_loss = val_loss_total / len(val_dataset)
    print(f"--> Target validation loss to beat: {best_val_loss:.4f}")
elif os.path.exists(TARGET_CHECKPOINT):
    print(f"--> '{SOURCE_CHECKPOINT}' not found. Loading from '{TARGET_CHECKPOINT}'...")
    model.load_state_dict(torch.load(TARGET_CHECKPOINT, map_location=device))
    
    model.eval()
    val_loss_total = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images.to(device))
            val_loss_total += criterion(outputs, labels.to(device)).item() * len(labels)
    best_val_loss = val_loss_total / len(val_dataset)
    print(f"--> Target validation loss to beat: {best_val_loss:.4f}")
else:
    print("--> No existing checkpoint found. Training from default ImageNet initialization...")
    best_val_loss = float("inf")

# ==========================================
# 6. TRAINING LOOP WITH EARLY STOPPING
# ==========================================
log_lines = []
def log_and_print(text):
    print(text)
    log_lines.append(text + "\n")

log_and_print(f"--- Training ResNet-18 (layer3+layer4+fc) on {device} ---")
log_and_print(f"Source Checkpoint : {SOURCE_CHECKPOINT} (Locked)")
log_and_print(f"Target Checkpoint : {TARGET_CHECKPOINT} (Overwritten only on improvement)")

epochs_no_improve = 0
best_epoch = 0
start_time = time.time()

for epoch in range(NUM_EPOCHS):
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * len(labels)

    train_loss = running_loss / len(train_dataset)

    model.eval()
    val_loss_total = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images.to(device))
            val_loss_total += criterion(outputs, labels.to(device)).item() * len(labels)
    val_loss = val_loss_total / len(val_dataset)

    # Save exclusively to TARGET_CHECKPOINT, preserving SOURCE_CHECKPOINT intact
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        best_epoch = epoch + 1
        epochs_no_improve = 0
        torch.save(model.state_dict(), TARGET_CHECKPOINT)
        marker = " *"
    else:
        epochs_no_improve += 1
        marker = f" (no improvement: {epochs_no_improve}/{PATIENCE})"

    log_and_print(f"Epoch [{epoch+1}/{NUM_EPOCHS}] - Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f}{marker}")

    if epochs_no_improve >= PATIENCE:
        log_and_print(f"\n--> Early stopping triggered at epoch {epoch+1}. Best validation loss achieved at epoch {best_epoch}.")
        break

total_time = time.time() - start_time
log_and_print(f"Total Session Time: {total_time:.2f}s ({total_time / (epoch + 1):.2f} s/epoch)")

# ==========================================
# 7. EVALUATION ON TEST SET
# ==========================================
eval_path = TARGET_CHECKPOINT if os.path.exists(TARGET_CHECKPOINT) else SOURCE_CHECKPOINT
print(f"\n--> Evaluating best model weights ({eval_path}) on Test Set...")
model.load_state_dict(torch.load(eval_path, map_location=device))
model.eval()

predictions = []
true_labels = []

with torch.no_grad():
    for images, labels in test_loader:
        preds = model(images.to(device)).argmax(dim=1).cpu()
        predictions.append(preds)
        true_labels.append(labels)

predictions = torch.cat(predictions).numpy()
true_labels = torch.cat(true_labels).numpy()

test_acc = (predictions == true_labels).mean() * 100
log_and_print(f"\nFinal Test Accuracy: {test_acc:.2f}%")

confusion = np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=int)
for true, pred in zip(true_labels, predictions):
    confusion[true, pred] += 1

log_and_print(f"\nClasses: {CLASSES}")
log_and_print("Confusion Matrix (rows = true class, columns = predicted class):")
log_and_print(str(confusion))

with open(LOG_FILE, "w") as f:
    f.writelines(log_lines)

print(f"\n[DONE] Results logged to {LOG_FILE}. Saved model: {eval_path}")