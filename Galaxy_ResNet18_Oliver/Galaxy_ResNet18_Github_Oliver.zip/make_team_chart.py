import matplotlib.pyplot as plt

# ==========================================
# 1. MODEL DATA, ACCURACY & PARAMETER COUNTS
# ==========================================
models = [
    "Class Baseline\n(VGG Random Weights)",
    "VGG-16\n(Sequential CNN)",
    "ResNet-18\n(Residual CNN)",
    "DETR w/ MobileNetV4\n(Mobile Transformer)",
    "DINOv2\n(Vision Transformer)"
]

# Accuracies across baseline and all evaluated architectures
accuracies = [24.7, 64.10, 75.67, 83.62, 85.15]

# Parameter counts per model
params = [
    "~138M params",   # Theoretical baseline (zero learning)
    "~138M",      # VGG-16 baseline
    "~11.7M",      # ResNet-18
    "~2.7M",       # MobileNetV4 (Highlighted)
    "~22M"        # DINOv2 ViT-B/14
]

# Color palette: neutral slate for baselines, vibrant hues for trained models
bar_colors = [
    "#475569",  # Dark slate for class baseline
    "#64748B",  # Muted slate for VGG-16
    "#38BDF8",  # Sky blue for your ResNet-18
    "#0EA5E9",  # Deep cyan for MobileNetV4
    "#A855F7"   # Purple for DINOv2
]

# ==========================================
# 2. PLOT PRESENTATION GRAPHIC
# ==========================================
plt.style.use("dark_background")
fig, ax = plt.subplots(figsize=(10.5, 5.5), facecolor="#0B1120")
ax.set_facecolor("#0B1120")

# Adjusted bar width to 0.45 for clean spacing across 5 categories
bars = ax.bar(models, accuracies, color=bar_colors, width=0.45, zorder=3)

# Add Accuracy badges and Parameter labels above each bar
for bar, acc, param in zip(bars, accuracies, params):
    # Top Accuracy Badge
    ax.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 1.2,
        f"{acc:.2f}%",
        ha="center",
        va="bottom",
        fontsize=11.5,
        fontweight="bold",
        color="#F3F4F6"
    )

    # Highlight 2.7M in emerald green; others in muted gray
    is_highlight = "2.7M" in param
    param_text = f"★ {param}" if is_highlight else f"{param}"
    param_color = "#34D399" if is_highlight else "#94A3B8"
    font_weight = "bold" if is_highlight else "normal"
    font_size = 10.5 if is_highlight else 9.5

    ax.text(
        bar.get_x() + bar.get_width() / 2,
        bar.get_height() + 5.2,
        param_text,
        ha="center",
        va="bottom",
        fontsize=font_size,
        fontweight=font_weight,
        color=param_color
    )

# Formatting axes, limits, and gridlines
ax.set_ylim(0, 105)
ax.set_ylabel("Accuracy (%)", fontsize=12, fontweight="bold", color="#E5E7EB", labelpad=10)
ax.set_title("Team Model Comparison: Accuracy & Parameters", fontsize=15, fontweight="bold", color="#FFFFFF", pad=16)

ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.spines["left"].set_color("#4B5563")
ax.spines["bottom"].set_color("#4B5563")

ax.tick_params(axis="x", labelsize=9.5, colors="#F3F4F6")
ax.tick_params(axis="y", labelsize=10, colors="#9CA3AF")
ax.yaxis.grid(True, linestyle="--", alpha=0.25, color="#9CA3AF", zorder=0)

plt.tight_layout()

# Save updated presentation graphic
output_filename = "team_model_comparison.png"
plt.savefig(output_filename, dpi=300, bbox_inches="tight", facecolor=fig.get_facecolor())
print(f"[SUCCESS] Updated 5-bar chart saved to '{output_filename}'!")