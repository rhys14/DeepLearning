import os
import time
import numpy as np
import torch
import torchvision
from PIL import Image
from datasets import load_dataset
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler  # CHANGED: added WeightedRandomSampler

# ==========================================
# 1. SETTINGS & HYPERPARAMETERS
# ==========================================
CLASSES = [
    "disturbed", "merging", "round_smooth", "in_between_round_smooth", "cigar_smooth",
    "barred_spiral", "unbarred_tight_spiral", "unbarred_loose_spiral",
    "edge_on_no_bulge", "edge_on_with_bulge"
]
NUM_CLASSES = len(CLASSES)
BATCH_SIZE = 32
NUM_EPOCHS = 25       # Number of additional epochs to run
PATIENCE = 6          # Early stopping patience
NUM_WORKERS = 2       # Set to 0 if your server gives multiprocessing/worker errors
# CHANGED: new file names so this run does NOT resume from (or overwrite) the non-oversampled run
LOG_FILE = "results_WRS.txt"
CHECKPOINT_PATH = "resnet18_galaxy_WRS.pth"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"--> Using device: {device}")

# ==========================================
# 2. DATA AUGMENTATION & TRANSFORMS
# ==========================================
train_transform = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),
    torchvision.transforms.RandomCrop(224),
    torchvision.transforms.RandomHorizontalFlip(p=0.5),
    torchvision.transforms.RandomVerticalFlip(p=0.5),
    torchvision.transforms.RandomRotation(degrees=(0, 360)),
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

eval_transform = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),
    torchvision.transforms.CenterCrop(224),
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# ==========================================
# 3. LOAD FULL DATASET & CREATE SPLITS
# ==========================================
print("--> Loading full Galaxy10 DECALS dataset (17,736 images)...")
raw_dataset = load_dataset("matthieulel/galaxy10_decals", split="train")

# 70% Train, 15% Validation, 15% Test
split_1 = raw_dataset.train_test_split(test_size=0.30, seed=42)
train_raw = split_1["train"]
split_2 = split_1["test"].train_test_split(test_size=0.50, seed=42)
val_raw = split_2["train"]
test_raw = split_2["test"]

print(f"--> Split sizes: Train={len(train_raw)}, Validation={len(val_raw)}, Test={len(test_raw)}")

class GalaxyDataset(Dataset):
    def __init__(self, hf_data, transform=None):
        self.data = hf_data
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        img = item["image"].convert("RGB")
        label = item["label"]
        if self.transform:
            img = self.transform(img)
        return img, label

train_dataset = GalaxyDataset(train_raw, transform=train_transform)
val_dataset = GalaxyDataset(val_raw, transform=eval_transform)
test_dataset = GalaxyDataset(test_raw, transform=eval_transform)

# ------------------------------------------
# CHANGED: oversampling with WeightedRandomSampler (training set only)
# Each sample gets weight 1 / (count of its class), so every class is drawn about equally often.
# Rare classes (cigar_smooth) are drawn with replacement, i.e. repeated; the random flips/rotations
# in train_transform make each repeat look different.
# ------------------------------------------
train_labels = np.array(train_raw["label"])   # reads the label column only, doesn't decode images
class_counts = np.bincount(train_labels, minlength=NUM_CLASSES)
print("--> Training class counts:", dict(zip(CLASSES, class_counts.tolist())))

sample_weights = torch.tensor(1.0 / class_counts[train_labels], dtype=torch.double)
sampler = WeightedRandomSampler(
    weights=sample_weights,
    num_samples=len(train_dataset),           # same number of samples (and steps) per epoch as before
    replacement=True,
    generator=torch.Generator().manual_seed(42),
)

# CHANGED: sampler replaces shuffle=True (the two are mutually exclusive)
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, sampler=sampler, num_workers=NUM_WORKERS, pin_memory=True)
# Validation and test loaders are unchanged: they keep the natural class mix
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, pin_memory=True)

# ==========================================
# 4. MODEL SETUP WITH FINE-TUNING (LAYER4 + FC)
# ==========================================
print("--> Initializing ResNet-18 model architecture...")
weights = torchvision.models.ResNet18_Weights.IMAGENET1K_V1
model = torchvision.models.resnet18(weights=weights)

# Freeze all layers initially
for param in model.parameters():
    param.requires_grad = False

# # Unfreeze layer3 for fine-tuning
# for param in model.layer3.parameters():
#     param.requires_grad = True
    
# # Unfreeze layer4 for fine-tuning
# for param in model.layer4.parameters():
#     param.requires_grad = True

# Replace the classification head for 10 galaxy categories
in_features = model.fc.in_features
model.fc = torch.nn.Linear(in_features, NUM_CLASSES)
model = model.to(device)

criterion = torch.nn.CrossEntropyLoss()

# Differential learning rates
optimizer = torch.optim.AdamW([
    # {"params": model.layer3.parameters(), "lr": 3e-5},
    # {"params": model.layer4.parameters(), "lr": 1e-4},
    {"params": model.fc.parameters(), "lr": 5e-4}
], weight_decay=1e-2)

# ==========================================
# 5. RESUME FROM PREVIOUS BEST CHECKPOINT
# ==========================================
if os.path.exists(CHECKPOINT_PATH):
    print(f"--> Found existing checkpoint '{CHECKPOINT_PATH}'!")
    print("--> Loading weights from previous best epoch...")
    model.load_state_dict(torch.load(CHECKPOINT_PATH, map_location=device))
    
    # Establish the true baseline validation loss from the loaded checkpoint
    model.eval()
    val_loss_total = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images.to(device))
            val_loss_total += criterion(outputs, labels.to(device)).item() * len(labels)
    best_val_loss = val_loss_total / len(val_dataset)
    print(f"--> Baseline validation loss to beat: {best_val_loss:.4f}")
else:
    print("--> No previous checkpoint found. Starting training from scratch...")
    best_val_loss = float("inf")

# ==========================================
# 6. TRAINING LOOP WITH EARLY STOPPING
# ==========================================
log_lines = []
def log_and_print(text):
    print(text)
    log_lines.append(text + "\n")

log_and_print(f"--- Continuing ResNet-18 Training on {device} (Max {NUM_EPOCHS} Epochs, Patience {PATIENCE}) [WeightedRandomSampler] ---")
epochs_no_improve = 0
best_epoch = 0
start_time = time.time()

for epoch in range(NUM_EPOCHS):
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        running_loss += loss.item() * len(labels)

    train_loss = running_loss / len(train_dataset)

    model.eval()
    val_loss_total = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            outputs = model(images.to(device))
            val_loss_total += criterion(outputs, labels.to(device)).item() * len(labels)
    val_loss = val_loss_total / len(val_dataset)

    # Only save if this epoch beats the previous overall best
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        best_epoch = epoch + 1
        epochs_no_improve = 0
        torch.save(model.state_dict(), CHECKPOINT_PATH)
        marker = " *"
    else:
        epochs_no_improve += 1
        marker = f" (no improvement: {epochs_no_improve}/{PATIENCE})"

    log_and_print(f"Epoch [{epoch+1}/{NUM_EPOCHS}] - Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f}{marker}")

    if epochs_no_improve >= PATIENCE:
        log_and_print(f"\n--> Early stopping triggered at epoch {epoch+1}. Model reached best convergence.")
        break

total_time = time.time() - start_time
log_and_print(f"Total Session Time: {total_time:.2f} seconds ({total_time / (epoch + 1):.2f} s/epoch)")

# ==========================================
# 7. EVALUATION ON TEST SET
# ==========================================
print(f"--> Evaluating best checkpoint on Test Set...")
model.load_state_dict(torch.load(CHECKPOINT_PATH, map_location=device))
model.eval()

predictions = []
true_labels = []

with torch.no_grad():
    for images, labels in test_loader:
        preds = model(images.to(device)).argmax(dim=1).cpu()
        predictions.append(preds)
        true_labels.append(labels)

predictions = torch.cat(predictions).numpy()
true_labels = torch.cat(true_labels).numpy()

test_acc = (predictions == true_labels).mean() * 100
log_and_print(f"\nFinal Test Accuracy: {test_acc:.2f}%")

# Confusion Matrix
confusion = np.zeros((NUM_CLASSES, NUM_CLASSES), dtype=int)
for true, pred in zip(true_labels, predictions):
    confusion[true, pred] += 1

log_and_print(f"\nClasses: {CLASSES}")
log_and_print("Confusion Matrix (rows = true class, columns = predicted class):")
log_and_print(str(confusion))

with open(LOG_FILE, "w") as f:
    f.writelines(log_lines)

print(f"\n[DONE] Model saved to {CHECKPOINT_PATH} and results saved to {LOG_FILE}!")