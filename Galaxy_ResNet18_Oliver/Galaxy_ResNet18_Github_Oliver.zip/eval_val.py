import os
import torch
import torchvision
from datasets import load_dataset
from torch.utils.data import DataLoader, Dataset

# 1. Configuration & Model Setup
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
CHECKPOINT_PATH = "resnet18_galaxy10_76pct.pth"  # Or "resnet18_galaxy_finetuned.pth"
BATCH_SIZE = 32
NUM_CLASSES = 10

# Deterministic validation transform (same as training script)
eval_transform = torchvision.transforms.Compose([
    torchvision.transforms.Resize(256),
    torchvision.transforms.CenterCrop(224),
    torchvision.transforms.ToTensor(),
    torchvision.transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 2. Re-create the deterministic validation split (seed=42)
print("--> Loading dataset split...")
raw_dataset = load_dataset("matthieulel/galaxy10_decals", split="train")
split_1 = raw_dataset.train_test_split(test_size=0.30, seed=42)
split_2 = split_1["test"].train_test_split(test_size=0.50, seed=42)
val_raw = split_2["train"]

class GalaxyDataset(Dataset):
    def __init__(self, hf_data, transform=None):
        self.data = hf_data
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        item = self.data[idx]
        img = item["image"].convert("RGB")
        label = item["label"]
        if self.transform:
            img = self.transform(img)
        return img, label

val_dataset = GalaxyDataset(val_raw, transform=eval_transform)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# 3. Load model architecture and saved weights
print(f"--> Loading weights from {CHECKPOINT_PATH}...")
model = torchvision.models.resnet18(weights=None)
model.fc = torch.nn.Linear(model.fc.in_features, NUM_CLASSES)
model.load_state_dict(torch.load(CHECKPOINT_PATH, map_location=device))
model = model.to(device)
model.eval()

# 4. Compute Validation Accuracy and Loss
criterion = torch.nn.CrossEntropyLoss()
val_loss_total = 0.0
correct = 0
total = 0

with torch.no_grad():
    for images, labels in val_loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        loss = criterion(outputs, labels)
        val_loss_total += loss.item() * len(labels)
        
        preds = outputs.argmax(dim=1)
        correct += (preds == labels).sum().item()
        total += len(labels)

val_accuracy = (correct / total) * 100
val_loss = val_loss_total / total

print("\n" + "=" * 45)
print(f" Model Checkpoint    : {CHECKPOINT_PATH}")
print(f" Validation Images   : {total}")
print(f" Validation Accuracy : {val_accuracy:.2f}%")
print(f" Validation Loss     : {val_loss:.4f}")
print("=" * 45 + "\n")